# AI Hub

Minimal Next.js project that proxies to multiple AI providers.

## Setup
1. Create a GitHub repo and upload this project.
2. Add HF_API_KEY and OPENROUTER_API_KEY in Vercel env vars.
3. Deploy.

